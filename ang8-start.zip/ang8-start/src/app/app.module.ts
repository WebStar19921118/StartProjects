import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HomeModule } from './pages/home_page/modules/home/home.module';
import { HerolistModule } from './pages/herolist_page/modules/herolist/herolist.module';
import { CommModule } from './pages/common/comm/comm.module';


@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,

    HomeModule,
    HerolistModule,
    CommModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
