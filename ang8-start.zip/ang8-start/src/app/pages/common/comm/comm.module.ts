import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CommRoutingModule } from '../comm-routing/comm-routing.module';

import { Page404Component } from '../page404/page404.component';

@NgModule({
  declarations: [
    Page404Component
  ],
  imports: [
    CommonModule,
    CommRoutingModule
  ]
})
export class CommModule { }
